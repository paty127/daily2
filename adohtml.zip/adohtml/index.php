<!doctype html>
<html>
	<head>
		<meta charset="UTF-8">
		
		<title> Formulário HTML </title>
		
		<style>
		label{
			display: block;
		}
		</style>
	</head>
	
	<body>
		<form action="enviar.php" method="post">
		<fieldset>
            <fieldset class="grupo">
                <div class="campo">
                    <label for="nome">Nome</label>
                   <input type="text" name="nome" id="nome" required style="width: 10em" value="">
                </div>
                <div class="campo">
                    <label for="snome">Sobrenome</label>
                    <input type="text" name="snome" id="snome" required style="width: 10em" value="">
                </div>
            </fieldset>
            <div class="campo">
                <label>Sexo</label>
                <label>
                    <input type="radio" name="sexo" value="masculino" required> Masculino
                </label>
                <label>
                    <input type="radio" name="sexo" value="feminino" required> Feminino
                </label>
            </div>
            <div class="campo">
                <label for="email">E-mail</label>
                <input type="text" name="email" id="email" required style="width: 20em" value="">
            </div>
            <div class="campo">
                <label for="telefone">Telefone</label>
                <input type="numeric" name="telefone"  id="telefone" required style="width: 10em" value="">
            </div>
            <div class="campo">
                <label for="data de nascimento">nascimento</label>
                <input type="date" name="nascimento" id="data de nascimento" required style="width: 10em" value="">
            </div>
        
    
            <fieldset class="grupo">
                <div class="campo">
                   
                    </select>
                </div>
            </fieldset>
    
            <div class="campo">
                <label for="mensagem">Mensagem</label>
                <textarea rows="6" style="width: 20em" id="mensagem" name="mensagem"></textarea>
            </div>
    
            <div class="campo">
                <label>Tipo de mensagem</label>
                <label>
                    <input type="checkbox" name="reclamação" value="1"> Reclamação
                </label>
                <label>
                    <input type="checkbox" name="sugestão" value="2"> Sugestão
                </label>
                <label>
                    <input type="checkbox" name="elogio" value="3"> Elogio
                </label>

            </div>
    
            <button type="submit" name="submit">Enviar</button>
        </fieldset>
		</form>
	</body>
</html>